# UC access

Extension para desbloquear acceso a papers y artículos usando tu cuenta UC.

La puedes instalar en [Google Chrome](https://chrome.google.com/webstore/detail/uc-access/leoijilpkelhgbhkneanedjffjhedcoa)
o en [Firefox](https://addons.mozilla.org/en-US/firefox/addon/uc-access/).

Probado en Chrome y Firefox, pero debería funcionar en cualquier navegador que soporte WebExtensions API (Opera, Edge, Brave, Vivaldi)

Cualquier duda o sugerencia no duden en abrir  una *Issue* o enviarme un correo.

-----
Esta es una extensión no oficial y no guarda relación alguna con la Pontificia Universidad Católica de Chile.
